#Turn off reverse path filtering

sudo sysctl -w net.ipv4.conf.all.rp_filter=0
sudo sysctl -w net.ipv4.conf.default.rp_filter=0
ifconfig -a | grep eth | awk '{ if (substr($1,4,4) !=0) { print "sudo sysctl -w net.ipv4.conf." $1 ".rp_filter=0"}}' |sh
