#!/bin/bash
#restart the interfaces
ifconfig -a | grep eth | awk '{ if (substr($1,4,4) !=0) { print "sudo ifconfig " $1 " down"}}' |sh

ifconfig -a | grep eth | awk '{ if (substr($1,4,4) !=0) { print "sudo ifconfig " $1 " up"}}' |sh

